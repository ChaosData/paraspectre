module Readline
  module Version
    VERSION = "1.0"
    JLINE_VERSION = "2.11"
  end
end
