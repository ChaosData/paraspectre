use ruby-maven to have the version changes propagated into the pom.xml

## deploy snaphot

    rmvn deploy

needs to gem prerelease version

## deploy release

    rmvn -Prelease

needs to gem release version
